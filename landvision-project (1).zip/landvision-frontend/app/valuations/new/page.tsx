'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import ResultCard, { ResultItem } from '@/components/ResultCard';
import api from '@/lib/api';
import Link from 'next/link';

function ValuationFormContent() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    cityId: '',
    propertyType: 'APARTMENT',
    area: '',
    bedrooms: '',
    bathrooms: '',
    parkingSpaces: '0',
  });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await api.post('/valuations', {
        ...formData,
        area: parseFloat(formData.area),
        bedrooms: parseInt(formData.bedrooms),
        bathrooms: parseInt(formData.bathrooms),
        parkingSpaces: parseInt(formData.parkingSpaces),
      });
      setResult(response.data.data);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to create valuation');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <nav className="container-custom py-4 flex justify-between items-center">
          <Link href="/dashboard" className="text-2xl font-bold text-primary-600">LandVision</Link>
          <Link href="/dashboard" className="btn btn-outline">Back to Dashboard</Link>
        </nav>
      </header>

      <main className="container-custom py-12">
        <h1 className="text-3xl font-bold mb-8">Property Valuation</h1>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form */}
          <div className="card">
            <h2 className="text-xl font-semibold mb-6">Property Details</h2>
            
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City ID (UUID)</label>
                <input
                  type="text"
                  value={formData.cityId}
                  onChange={(e) => setFormData({ ...formData, cityId: e.target.value })}
                  className="input"
                  required
                  placeholder="Enter city UUID"
                />
                <p className="text-xs text-gray-500 mt-1">Get city IDs from /api/regions/countries/:countryId/states/:stateId/cities</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Type</label>
                <select
                  value={formData.propertyType}
                  onChange={(e) => setFormData({ ...formData, propertyType: e.target.value })}
                  className="input"
                  required
                >
                  <option value="APARTMENT">Apartment</option>
                  <option value="HOUSE">House</option>
                  <option value="CONDO">Condo</option>
                  <option value="LAND">Land</option>
                  <option value="COMMERCIAL">Commercial</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Area (m²)</label>
                  <input
                    type="number"
                    value={formData.area}
                    onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                    className="input"
                    required
                    step="0.01"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bedrooms</label>
                  <input
                    type="number"
                    value={formData.bedrooms}
                    onChange={(e) => setFormData({ ...formData, bedrooms: e.target.value })}
                    className="input"
                    required
                    min="0"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bathrooms</label>
                  <input
                    type="number"
                    value={formData.bathrooms}
                    onChange={(e) => setFormData({ ...formData, bathrooms: e.target.value })}
                    className="input"
                    required
                    min="0"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Parking Spaces</label>
                  <input
                    type="number"
                    value={formData.parkingSpaces}
                    onChange={(e) => setFormData({ ...formData, parkingSpaces: e.target.value })}
                    className="input"
                    min="0"
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary w-full" disabled={loading}>
                {loading ? 'Analyzing...' : 'Get Valuation'}
              </button>
            </form>
          </div>

          {/* Results */}
          {result && (
            <div className="space-y-6">
              <ResultCard title="Valuation Results">
                <ResultItem label="Estimated Value" value={`$${result.estimatedValue?.toLocaleString()}`} />
                <ResultItem label="Min Value" value={`$${result.minValue?.toLocaleString()}`} />
                <ResultItem label="Max Value" value={`$${result.maxValue?.toLocaleString()}`} />
                <ResultItem label="Confidence Score" value={`${(result.confidenceScore * 100).toFixed(0)}%`} />
              </ResultCard>

              {result.aiAnalysis && (
                <ResultCard title="AI Analysis">
                  <p className="text-gray-700">{result.aiAnalysis}</p>
                </ResultCard>
              )}

              {result.marketTrends && (
                <ResultCard title="Market Trends">
                  <p className="text-gray-700">{result.marketTrends}</p>
                </ResultCard>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default function ValuationPage() {
  return (
    <ProtectedRoute>
      <ValuationFormContent />
    </ProtectedRoute>
  );
}
