'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import ResultCard, { ResultItem } from '@/components/ResultCard';
import api from '@/lib/api';
import Link from 'next/link';

function DecisionFormContent() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    propertyValue: '',
    rentalValue: '',
    downPayment: '',
    interestRate: '',
    loanTerm: '',
    monthlyIncome: '',
  });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const payload: any = {
        propertyValue: parseFloat(formData.propertyValue),
      };
      if (formData.rentalValue) payload.rentalValue = parseFloat(formData.rentalValue);
      if (formData.downPayment) payload.downPayment = parseFloat(formData.downPayment);
      if (formData.interestRate) payload.interestRate = parseFloat(formData.interestRate);
      if (formData.loanTerm) payload.loanTerm = parseInt(formData.loanTerm);
      if (formData.monthlyIncome) payload.monthlyIncome = parseFloat(formData.monthlyIncome);

      const response = await api.post('/decisions', payload);
      setResult(response.data.data);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to create decision analysis');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <nav className="container-custom py-4 flex justify-between items-center">
          <Link href="/dashboard" className="text-2xl font-bold text-primary-600">LandVision</Link>
          <Link href="/dashboard" className="btn btn-outline">Back to Dashboard</Link>
        </nav>
      </header>

      <main className="container-custom py-12">
        <h1 className="text-3xl font-bold mb-8">Decision Analysis</h1>
        <p className="text-gray-600 mb-8">Analyze whether you should buy, rent, or invest in real estate</p>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form */}
          <div className="card">
            <h2 className="text-xl font-semibold mb-6">Financial Details</h2>
            
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Property Value ($) *</label>
                <input
                  type="number"
                  value={formData.propertyValue}
                  onChange={(e) => setFormData({ ...formData, propertyValue: e.target.value })}
                  className="input"
                  required
                  step="0.01"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Rental Value ($)</label>
                <input
                  type="number"
                  value={formData.rentalValue}
                  onChange={(e) => setFormData({ ...formData, rentalValue: e.target.value })}
                  className="input"
                  step="0.01"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Down Payment ($)</label>
                <input
                  type="number"
                  value={formData.downPayment}
                  onChange={(e) => setFormData({ ...formData, downPayment: e.target.value })}
                  className="input"
                  step="0.01"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Interest Rate (%)</label>
                  <input
                    type="number"
                    value={formData.interestRate}
                    onChange={(e) => setFormData({ ...formData, interestRate: e.target.value })}
                    className="input"
                    step="0.01"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Loan Term (months)</label>
                  <input
                    type="number"
                    value={formData.loanTerm}
                    onChange={(e) => setFormData({ ...formData, loanTerm: e.target.value })}
                    className="input"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Income ($)</label>
                <input
                  type="number"
                  value={formData.monthlyIncome}
                  onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                  className="input"
                  step="0.01"
                />
              </div>

              <button type="submit" className="btn btn-primary w-full" disabled={loading}>
                {loading ? 'Analyzing...' : 'Analyze Decision'}
              </button>
            </form>
          </div>

          {/* Results */}
          {result && (
            <div className="space-y-6">
              <ResultCard title="Recommendation">
                <div className="text-center py-4">
                  <div className="text-4xl font-bold text-primary-600 mb-2">{result.recommendation}</div>
                  <div className="text-lg text-gray-600">Confidence: {result.score}/100</div>
                </div>
              </ResultCard>

              {result.buyAnalysis && (
                <ResultCard title="Buying Analysis">
                  <p className="text-gray-700">{result.buyAnalysis}</p>
                </ResultCard>
              )}

              {result.rentAnalysis && (
                <ResultCard title="Renting Analysis">
                  <p className="text-gray-700">{result.rentAnalysis}</p>
                </ResultCard>
              )}

              {result.investAnalysis && (
                <ResultCard title="Investment Analysis">
                  <p className="text-gray-700">{result.investAnalysis}</p>
                </ResultCard>
              )}

              {result.reasoning && (
                <ResultCard title="Overall Reasoning">
                  <p className="text-gray-700">{result.reasoning}</p>
                </ResultCard>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default function DecisionPage() {
  return (
    <ProtectedRoute>
      <DecisionFormContent />
    </ProtectedRoute>
  );
}
