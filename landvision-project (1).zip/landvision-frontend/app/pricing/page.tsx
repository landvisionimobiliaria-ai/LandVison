'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { authService } from '@/lib/auth';

export default function PricingPage() {
  const router = useRouter();
  const isAuth = authService.isAuthenticated();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="container-custom py-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-primary-600">LandVision</Link>
          <div className="space-x-4">
            {isAuth ? (
              <Link href="/dashboard" className="btn btn-primary">Dashboard</Link>
            ) : (
              <>
                <Link href="/login" className="btn btn-outline">Login</Link>
                <Link href="/register" className="btn btn-primary">Sign Up</Link>
              </>
            )}
          </div>
        </nav>
      </header>

      {/* Pricing Section */}
      <main className="container-custom py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
          <p className="text-xl text-gray-600">Start with our free plan or unlock unlimited features with PRO</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Free Plan */}
          <div className="card">
            <h3 className="text-2xl font-bold mb-2">Free</h3>
            <p className="text-4xl font-bold text-primary-600 mb-6">$0<span className="text-lg text-gray-600">/month</span></p>
            
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>5 Property Valuations</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>3 Decision Analyses</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>3 Financing Simulations</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Basic AI Analysis</span>
              </li>
            </ul>

            <Link href="/register" className="btn btn-outline w-full">
              Get Started Free
            </Link>
          </div>

          {/* PRO Plan */}
          <div className="card border-2 border-primary-600 relative">
            <div className="absolute top-0 right-0 bg-primary-600 text-white px-4 py-1 text-sm font-semibold rounded-bl-lg">
              POPULAR
            </div>
            
            <h3 className="text-2xl font-bold mb-2">PRO</h3>
            <p className="text-4xl font-bold text-primary-600 mb-6">$29<span className="text-lg text-gray-600">/month</span></p>
            
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span><strong>Unlimited</strong> Property Valuations</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span><strong>Unlimited</strong> Decision Analyses</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span><strong>Unlimited</strong> Financing Simulations</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Advanced AI Analysis</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Priority Support</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                <span>Export Reports</span>
              </li>
            </ul>

            <Link href="/register" className="btn btn-primary w-full">
              Start PRO Trial
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
