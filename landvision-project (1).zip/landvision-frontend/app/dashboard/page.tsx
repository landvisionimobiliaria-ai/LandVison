'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import ProtectedRoute from '@/components/ProtectedRoute';
import { authService } from '@/lib/auth';
import api from '@/lib/api';

function DashboardContent() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const profile = await authService.getProfile();
      setUser(profile);
    } catch (error) {
      console.error('Failed to load profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await authService.logout();
    router.push('/login');
  };

  if (loading) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <nav className="container-custom py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-primary-600">LandVision</h1>
          <div className="flex items-center space-x-4">
            <span className="text-gray-700">Welcome, {user?.name || user?.email}</span>
            <button onClick={handleLogout} className="btn btn-secondary">Logout</button>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="container-custom py-12">
        <h2 className="text-3xl font-bold mb-8">Dashboard</h2>

        {/* Subscription Info */}
        <div className="card mb-8">
          <h3 className="text-xl font-semibold mb-4">Your Plan: {user?.subscription?.plan || 'FREE'}</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-primary-600">{user?.subscription?.valuationsUsed || 0}</p>
              <p className="text-gray-600">Valuations Used</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary-600">{user?.subscription?.decisionsUsed || 0}</p>
              <p className="text-gray-600">Decisions Made</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary-600">{user?.subscription?.financingsUsed || 0}</p>
              <p className="text-gray-600">Financing Simulations</p>
            </div>
          </div>
          {user?.subscription?.plan === 'FREE' && (
            <div className="mt-4 text-center">
              <Link href="/pricing" className="btn btn-primary">Upgrade to PRO</Link>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <h3 className="text-2xl font-semibold mb-4">Quick Actions</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <Link href="/valuations/new" className="card hover:shadow-md transition-shadow">
            <h4 className="text-xl font-semibold mb-2">🏠 Property Valuation</h4>
            <p className="text-gray-600">Get AI-powered property value estimates</p>
          </Link>
          
          <Link href="/decisions/new" className="card hover:shadow-md transition-shadow">
            <h4 className="text-xl font-semibold mb-2">🧠 Decision Analysis</h4>
            <p className="text-gray-600">Analyze buy vs rent vs invest options</p>
          </Link>
          
          <Link href="/financing/new" className="card hover:shadow-md transition-shadow">
            <h4 className="text-xl font-semibold mb-2">💰 Financing Calculator</h4>
            <p className="text-gray-600">Simulate loan payments and terms</p>
          </Link>
        </div>
      </main>
    </div>
  );
}

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}
