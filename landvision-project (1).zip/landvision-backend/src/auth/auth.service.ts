import { prisma } from '../config/database';
import { generateAccessToken, generateRefreshToken, verifyRefreshToken, getTokenExpirationSeconds, JWT_CONFIG } from '../config/jwt';
import { blacklistToken } from '../config/redis';
import bcrypt from 'bcryptjs';
import { UnauthorizedError, ConflictError } from '../utils/errors';
import { logger } from '../utils/logger';

export const authService = {
  async register(email: string, password: string, name?: string) {
    const existingUser = await prisma.user.findUnique({ where: { email } });
    if (existingUser) throw new ConflictError('Email already exists');

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { email, passwordHash, name },
    });

    await prisma.subscription.create({
      data: { userId: user.id, plan: 'FREE', status: 'ACTIVE' },
    });

    const tokens = await this.generateTokens(user);
    return { user: this.sanitizeUser(user), ...tokens };
  },

  async login(email: string, password: string, userAgent?: string, ipAddress?: string) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.isActive) throw new UnauthorizedError('Invalid credentials');

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) throw new UnauthorizedError('Invalid credentials');

    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    const tokens = await this.generateTokens(user, userAgent, ipAddress);
    return { user: this.sanitizeUser(user), ...tokens };
  },

  async refreshToken(refreshToken: string) {
    const payload = verifyRefreshToken(refreshToken);
    const session = await prisma.session.findUnique({ where: { refreshToken } });

    if (!session || session.expiresAt < new Date()) {
      throw new UnauthorizedError('Invalid refresh token');
    }

    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!user || !user.isActive) throw new UnauthorizedError('User not found');

    const newAccessToken = generateAccessToken({ userId: user.id, email: user.email, role: user.role });
    return { accessToken: newAccessToken };
  },

  async logout(refreshToken: string, accessToken: string) {
    await prisma.session.deleteMany({ where: { refreshToken } });
    const expSeconds = getTokenExpirationSeconds(JWT_CONFIG.expiresIn);
    await blacklistToken(accessToken, expSeconds);
  },

  async generateTokens(user: any, userAgent?: string, ipAddress?: string) {
    const payload = { userId: user.id, email: user.email, role: user.role };
    const accessToken = generateAccessToken(payload);
    const refreshToken = generateRefreshToken(payload);

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await prisma.session.create({
      data: { userId: user.id, refreshToken, expiresAt, userAgent, ipAddress },
    });

    return { accessToken, refreshToken };
  },

  sanitizeUser(user: any) {
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  },
};
