import { Request, Response } from 'express';
import { regionsService } from './regions.service';
import { sendSuccess, sendCreated } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const regionsController = {
  getCountries: asyncHandler(async (req: Request, res: Response) => {
    const countries = await regionsService.getCountries();
    sendSuccess(res, countries);
  }),

  createCountry: asyncHandler(async (req: Request, res: Response) => {
    const country = await regionsService.createCountry(req.body);
    sendCreated(res, country);
  }),

  getStates: asyncHandler(async (req: Request, res: Response) => {
    const { countryId } = req.params;
    const states = await regionsService.getStates(countryId);
    sendSuccess(res, states);
  }),

  createState: asyncHandler(async (req: Request, res: Response) => {
    const state = await regionsService.createState(req.body);
    sendCreated(res, state);
  }),

  getCities: asyncHandler(async (req: Request, res: Response) => {
    const { stateId } = req.params;
    const cities = await regionsService.getCities(stateId);
    sendSuccess(res, cities);
  }),

  createCity: asyncHandler(async (req: Request, res: Response) => {
    const city = await regionsService.createCity(req.body);
    sendCreated(res, city);
  }),

  getNeighborhoods: asyncHandler(async (req: Request, res: Response) => {
    const { cityId } = req.params;
    const neighborhoods = await regionsService.getNeighborhoods(cityId);
    sendSuccess(res, neighborhoods);
  }),

  createNeighborhood: asyncHandler(async (req: Request, res: Response) => {
    const neighborhood = await regionsService.createNeighborhood(req.body);
    sendCreated(res, neighborhood);
  }),
};
