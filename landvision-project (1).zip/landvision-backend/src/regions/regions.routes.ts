import { Router } from 'express';
import { regionsController } from './regions.controller';
import { authenticate, authorize } from '../middleware/auth';
import { validate } from '../middleware/validation';
import { z } from 'zod';

const router = Router();

// Public routes
router.get('/countries', regionsController.getCountries);
router.get('/countries/:countryId/states', regionsController.getStates);
router.get('/states/:stateId/cities', regionsController.getCities);
router.get('/cities/:cityId/neighborhoods', regionsController.getNeighborhoods);

// Admin routes
const countrySchema = z.object({ name: z.string(), code: z.string(), currency: z.string() });
const stateSchema = z.object({ countryId: z.string(), name: z.string(), code: z.string() });
const citySchema = z.object({ stateId: z.string(), name: z.string() });
const neighborhoodSchema = z.object({ cityId: z.string(), name: z.string(), zone: z.string().optional() });

router.post('/countries', authenticate, authorize('ADMIN'), validate({ body: countrySchema }), regionsController.createCountry);
router.post('/states', authenticate, authorize('ADMIN'), validate({ body: stateSchema }), regionsController.createState);
router.post('/cities', authenticate, authorize('ADMIN'), validate({ body: citySchema }), regionsController.createCity);
router.post('/neighborhoods', authenticate, authorize('ADMIN'), validate({ body: neighborhoodSchema }), regionsController.createNeighborhood);

export default router;
