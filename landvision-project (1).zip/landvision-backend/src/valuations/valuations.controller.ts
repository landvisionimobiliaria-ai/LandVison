import { Request, Response } from 'express';
import { valuationsService } from './valuations.service';
import { sendSuccess, sendCreated } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const valuationsController = {
  create: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const valuation = await valuationsService.createValuation(userId, req.body);
    sendCreated(res, valuation);
  }),

  list: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const valuations = await valuationsService.getUserValuations(userId);
    sendSuccess(res, valuations);
  }),

  get: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const { id } = req.params;
    const valuation = await valuationsService.getValuation(id, userId);
    sendSuccess(res, valuation);
  }),
};
