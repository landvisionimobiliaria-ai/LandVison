import { stripe, STRIPE_PLANS } from '../config/stripe';
import { prisma } from '../config/database';
import { NotFoundError } from '../utils/errors';

export const paymentsService = {
  async createCheckoutSession(userId: string, plan: 'FREE' | 'PRO') {
    const user = await prisma.user.findUnique({ where: { id: userId }, include: { subscription: true } });
    if (!user) throw new NotFoundError('User not found');

    let customerId = user.subscription?.stripeCustomerId;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: user.email, metadata: { userId } });
      customerId = customer.id;
      await prisma.subscription.update({ where: { userId }, data: { stripeCustomerId: customerId } });
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [{ price: STRIPE_PLANS[plan], quantity: 1 }],
      mode: 'subscription',
      success_url: `${process.env.CORS_ORIGIN}/dashboard?success=true`,
      cancel_url: `${process.env.CORS_ORIGIN}/pricing?canceled=true`,
    });

    return { sessionId: session.id, url: session.url };
  },

  async handleWebhook(event: any) {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        const subscription = event.data.object;
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: subscription.status === 'active' ? 'ACTIVE' : 'CANCELED',
            stripePriceId: subscription.items.data[0].price.id,
            stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
          },
        });
        break;
      case 'customer.subscription.deleted':
        await prisma.subscription.updateMany({
          where: { stripeSubscriptionId: event.data.object.id },
          data: { status: 'CANCELED', plan: 'FREE' },
        });
        break;
    }
  },
};
