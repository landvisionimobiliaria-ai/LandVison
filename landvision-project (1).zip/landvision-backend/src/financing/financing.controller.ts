import { Request, Response } from 'express';
import { financingService } from './financing.service';
import { sendSuccess, sendCreated } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const financingController = {
  create: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const financing = await financingService.createFinancing(userId, req.body);
    sendCreated(res, financing);
  }),

  list: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const financings = await financingService.getUserFinancings(userId);
    sendSuccess(res, financings);
  }),

  get: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const { id } = req.params;
    const financing = await financingService.getFinancing(id, userId);
    sendSuccess(res, financing);
  }),
};
