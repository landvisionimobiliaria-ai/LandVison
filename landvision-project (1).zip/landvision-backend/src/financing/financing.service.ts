import { prisma } from '../config/database';
import { PaymentRequiredError, NotFoundError } from '../utils/errors';
import { PLAN_LIMITS } from '../config/stripe';

export const financingService = {
  async createFinancing(userId: string, data: any) {
    const subscription = await prisma.subscription.findUnique({ where: { userId } });
    if (!subscription) throw new NotFoundError('Subscription not found');

    const limit = PLAN_LIMITS[subscription.plan].financings;
    if (limit !== -1 && subscription.financingsUsed >= limit) {
      throw new PaymentRequiredError('Financing simulation limit exceeded. Please upgrade.');
    }

    const loanAmount = data.propertyValue - data.downPayment;
    const monthlyRate = data.interestRate / 100 / 12;
    const numberOfPayments = data.loanTerm;

    // Calculate monthly payment using amortization formula
    const monthlyPayment = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1);

    const totalPayment = monthlyPayment * numberOfPayments;
    const totalInterest = totalPayment - loanAmount;

    // Generate amortization schedule
    const schedule = [];
    let balance = loanAmount;

    for (let i = 1; i <= numberOfPayments; i++) {
      const interestPayment = balance * monthlyRate;
      const principalPayment = monthlyPayment - interestPayment;
      balance -= principalPayment;

      schedule.push({
        month: i,
        payment: Math.round(monthlyPayment * 100) / 100,
        principal: Math.round(principalPayment * 100) / 100,
        interest: Math.round(interestPayment * 100) / 100,
        balance: Math.round(Math.max(0, balance) * 100) / 100,
      });
    }

    const financing = await prisma.financing.create({
      data: {
        userId,
        propertyValue: data.propertyValue,
        downPayment: data.downPayment,
        loanAmount,
        interestRate: data.interestRate,
        loanTerm: data.loanTerm,
        monthlyPayment,
        totalPayment,
        totalInterest,
        amortizationSchedule: JSON.stringify(schedule),
      },
    });

    await prisma.subscription.update({ where: { userId }, data: { financingsUsed: { increment: 1 } } });

    return { ...financing, amortizationSchedule: schedule };
  },

  async getUserFinancings(userId: string) {
    const financings = await prisma.financing.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
    return financings.map(f => ({ ...f, amortizationSchedule: JSON.parse(f.amortizationSchedule || '[]') }));
  },

  async getFinancing(id: string, userId: string) {
    const financing = await prisma.financing.findFirst({ where: { id, userId } });
    if (!financing) throw new NotFoundError('Financing not found');
    return { ...financing, amortizationSchedule: JSON.parse(financing.amortizationSchedule || '[]') };
  },
};
