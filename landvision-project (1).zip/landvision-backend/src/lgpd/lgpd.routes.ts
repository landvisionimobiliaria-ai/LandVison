import { Router } from 'express';
import { lgpdController } from './lgpd.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

router.get('/export', authenticate, lgpdController.exportData);
router.post('/delete-request', authenticate, lgpdController.requestDeletion);

export default router;
