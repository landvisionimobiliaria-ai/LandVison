import { Request, Response } from 'express';
import { decisionsService } from './decisions.service';
import { sendSuccess, sendCreated } from '../utils/response';
import { asyncHandler } from '../middleware/errorHandler';

export const decisionsController = {
  create: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const decision = await decisionsService.createDecision(userId, req.body);
    sendCreated(res, decision);
  }),

  list: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const decisions = await decisionsService.getUserDecisions(userId);
    sendSuccess(res, decisions);
  }),

  get: asyncHandler(async (req: Request, res: Response) => {
    const userId = req.user!.userId;
    const { id } = req.params;
    const decision = await decisionsService.getDecision(id, userId);
    sendSuccess(res, decision);
  }),
};
